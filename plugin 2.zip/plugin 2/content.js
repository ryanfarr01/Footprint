// We're on an amazon fresh page
console.log("Hello from Footprint!")
console.log(window.location.pathname);

// Scan page for products, find their names and the divs containing them
var pageType = null;
if (window.location.pathname == "/b") {
  pageType = "browsing_page";
} else if (window.location.pathname == "other") {
  pageType = null;
}


var product_divs = null;

if (pageType == "browsing_page") {
  browsingPage();
}

function browsingPage() {
  var res = scanBrowsingPage();
  var product_names = res['names'];
  product_divs = res['divs'];
  // console.log(product_names);

  // Send a message to the background script in order to ping the API
  // product_names is a list of names ["15oz Apple Juice Box",""...]
  chrome.runtime.sendMessage(
    { message: "found_products", product_names: product_names});

  // Testing the labelling
  // labelItem(product_divs[0]);
}


// Look at html on page for products
// names: ["GoGo SqueeZ Organic Applesauce...", ""...]
// divs: [html_containing_product1, html...]
function scanBrowsingPage() {
  // var product_divs = document.getElementsByClassName("a-carousel-card");

  var product_divs = document.getElementsByClassName("a-box-group standard-kepler-widget-product p13n-asin");
  var product_names = [];
  for (i in product_divs) {
    if (product_divs[i] instanceof HTMLElement) {
      // console.log({"name": product_divs[i].querySelector("a.a-link-normal[title][href]").title});
      product_names.push({"name": product_divs[i].querySelector("a.a-link-normal[title][href]").title});
    }
  } 
  return {"names": product_names, "divs": product_divs};  
}


function labelItem(item_div, score) {
  var img = document.createElement("img");
  if (score > 0) {
    img.src = chrome.extension.getURL('labels/green.png');
    img.alt = "Green Footprint Score :)";
  }
  else {
    img.src = chrome.extension.getURL('labels/question.png');
    img.alt = "Unkown Footprint Score :?";

  }

  img.height = 50;
  img.width = 50;
  img.align = "Right"
  
  //grab the div with the fresh logo in it
  fresh_div = item_div.querySelector("div.a-box-group.a-spacing-none i.a-icon.a-icon-fresh.kepler-freshIcon");
  // console.log(item_div.childNodes);
  item_div.insertBefore(img, item_div.childNodes[5]);

  // item_div.appendChild(img);
  // console.log(item_div);
}

// Receive messages from background
chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
      console.log("Got message");
      if( request.message === "clicked_browser_action" ) {
        // var firstHref = $("a[href^='http']").eq(0).attr("href");
  
        console.log("here");
      }

      if (request.message == "received_scores") {
        console.log("Received scores from API");
        response = request.data;
        // console.log(response.items);
        for (r in response.items) {
          product_index = response.items[r]['index'];
          product_score = response.items[r]['score'];
          if (product_divs[product_index] != null) {
            labelItem(product_divs[product_index], product_score);
          }
        }
      }
    }
  );
