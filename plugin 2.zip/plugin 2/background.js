

const backend_url = "http://18.208.150.35:8000";



// Receiving messages from content script
chrome.runtime.onMessage.addListener(
  function (request, sender, sendResponse) {
    console.log(sender.tab ?
      "from a content script:" + sender.tab.url :
      "from the extenstion");
    if (request.message == "found_products") {
      // Found products on page, send list to API
      var product_list = request.product_names;
      sendProductListToAPI(product_list);
    }
  });

// Query API with list of products
// product_list: [{"name": "Juice"}, ...]
// sendResponse: callback fxn for data
function sendProductListToAPI(product_list) {
  var xhr = new XMLHttpRequest();
  xhr.open("POST", backend_url, true);
  xhr.setRequestHeader('Content-Type', 'application/json');
  xhr.send(JSON.stringify({
    "items": product_list 
  }));

  xhr.onreadystatechange = (e) => {
    console.log(xhr.responseText);
    console.log(JSON.parse(xhr.responseText));
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var activeTab = tabs[0];
      chrome.tabs.sendMessage(activeTab.id, {message: "received_scores", data: JSON.parse(xhr.responseText)});
    });
    // sendResponse(JSON.parse(xhr.responseText));
  }
}

// Called when the user clicks on the browser action.
chrome.browserAction.onClicked.addListener(function() {
  chrome.tabs.create({url: 'index.html'});
});
// chrome.browserAction.onClicked.addListener(function (tab) {
//   // Send a message to the active tab
//   chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
//     var activeTab = tabs[0];
//     chrome.tabs.sendMessage(activeTab.id, { "message": "clicked_browser_action" });
//   });
// });